import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormsModule } from '@angular/forms';
import { UserService } from './shared/userdata.service';

@NgModule({

  // it contains all the components
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent
  ],
  //modules
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  // services
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
