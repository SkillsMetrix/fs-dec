import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
  loadUsers(): string[] {
    return ['Admin', 'Manager', 'QA'];
  }
  loadCart(): string[] {
    return ['oil', 'soap', 'toothpaste'];
  }
  loadPeople(): any[] {
    return [
      {
        name: 'Admin',
        country: 'USA',
      },
      {
        name: 'Manager',
        country: 'Australia',
      },
      {
        name: 'charan',
        country: 'India',
      },
    ];
  }
}
