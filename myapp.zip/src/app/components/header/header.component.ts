import { Component } from '@angular/core';
import { UserService } from '../../shared/userdata.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  constructor(private us: UserService) {
    this.usersData = this.us.loadUsers();
    this.people=this.us.loadPeople()
  }
  
  people:any;
  usersData;
  projects = ['HRMS', 'Finance', 'Banking'];
  courses = [
    { id: 1, name: 'AngularApp' },
    { id: 2, name: 'ReactApp' },
    { id: 3, name: 'VueApp' },
  ];
  getColor(country: string) {
    switch (country) {
      case 'Australia':
        return 'blue';
      case 'USA':
        return 'green';
      case 'India':
        return 'purple';
      default:
        return null;
    }
  }

}
