import { Component, Input } from '@angular/core';
import { UserService } from '../../shared/userdata.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  constructor(private us:UserService){
    this.shopCart= this.us.loadCart()
  }
  shopCart
  myprofile='https://images.pexels.com/photos/3792581/pexels-photo-3792581.jpeg?cs=srgb&dl=pexels-bertellifotografia-3792581.jpg&fm=jpg'
  addUser(){
    alert('user is added')
  }
  @Input()
  mycity='mumbai'
}
