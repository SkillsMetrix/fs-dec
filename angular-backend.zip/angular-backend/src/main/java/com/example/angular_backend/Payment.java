package com.example.angular_backend;

public record Payment(
		String paymentId,
		String userId,
		String type, // UPI.CARD,CASH
		double amount
		
		
		) {

}
