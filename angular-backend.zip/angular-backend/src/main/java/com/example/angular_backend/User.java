package com.example.angular_backend;

public record User(Long id,String username,String email) {

}
