package com.example.angular_backend;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payments")
@CrossOrigin
public class AppController {
	
	private final PaymentProducer producer;
	private final List<User> users= new ArrayList<User>();
	
	public AppController(PaymentProducer producer) {
		 
		this.producer = producer;
	}
	@GetMapping("/welcome")
	public String sayWelcome() {
		return "Welcome to Payment Application";
	}
	
	@PostMapping("/register")
	public String registerUser(@RequestBody User user) {
		users.add(user);
		System.out.println("user added "+ user);
		return "User Added Successfully";
	}
	@PostMapping("/pay")
	public String payment(@RequestBody Payment payment) {
		producer.send(payment);
		System.out.println("Payment Sent to Kafka ");
		return "Payment Added";
	}
	
	
}
