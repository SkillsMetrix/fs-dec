package com.pack.kafkaApp;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.utils.Utils;

public class PaymentParti implements Partitioner{

	private Map<String, Integer> routing= new HashMap<String, Integer>();
	@Override
	public void configure(Map<String, ?> configs) {
		routing.put("upi", 0); 
		routing.put("card", 1); 
		routing.put("cash", 2); 
 		
	}

	@Override
	public int partition(String topic, Object keyobj, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		 int numParti= cluster.partitionCountForTopic(topic);
		 if(keyobj == null) {
			 return 0;
		 }
		String key= keyobj.toString().toLowerCase();
		if(routing.containsKey(key)) {
			return routing.get(key) % numParti;
		}
		return Utils.toPositive(key.hashCode()) % numParti;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
