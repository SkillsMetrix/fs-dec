package com.pack.kafkaApp;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

public class PaymentProducer {

	public static void main(String[] args) throws Exception {
		 String bootstrap = "localhost:9092";
	        String topic = "payment-topic";

	        Properties props = new Properties();
	        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
	        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
	                  "org.apache.kafka.common.serialization.StringSerializer");
	        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
	                  "org.apache.kafka.common.serialization.StringSerializer");

	        // Tell producer to use our custom partitioner
	        props.put(ProducerConfig.PARTITIONER_CLASS_CONFIG,
	                  "com.pack.kafkaApp.PaymentParti");

	        Producer<String, String> producer = new KafkaProducer<>(props);

	        // messages with keys
	        String[] keys = new String[] {
	            "upi",    
	            "card",     
	            "cash",        
	            "upi",        
	            "card"
	        };

	        for (int i = 0; i < keys.length; i++) {
	            String key = keys[i];
	            String value = "message-" + i + " for " + key;
	            ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);

	            // send synchronously to show partition chosen (you can use callback instead)
	            RecordMetadata meta = producer.send(record).get();
	            System.out.printf("Sent key=%s to partition=%d offset=%d%n",
	                              key, meta.partition(), meta.offset());
	        }

	        producer.close();
	    }
}
