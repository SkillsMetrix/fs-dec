package com.pack.kafkaApp;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.utils.Utils;

import java.util.Map;
import java.util.HashMap;

public class CustomPartitioner implements Partitioner {

    // explicit mapping: exact key -> partition
    private final Map<String, Integer> keyToPartition = new HashMap<>();

    @Override
    public void configure(Map<String, ?> configs) {
        
        keyToPartition.put("important-key", 0);    // force to partition 0
        keyToPartition.put("billing-key", 1);      // force to partition 1

        // Example: keys with prefix "vip-" -> partition 2 (handled in partition(...) method)
    }

    @Override
    public int partition(String topic, Object keyObj, byte[] keyBytes,
                         Object value, byte[] valueBytes, Cluster cluster) {

        int numPartitions = cluster.partitionCountForTopic(topic);

        // If no key, fallback to default round-robin/hash on value
        if (keyObj == null) {
            // fallback: hash of value or 0
            return Utils.toPositive((value == null ? 0 : value.hashCode())) % numPartitions;
        }

        String key = keyObj.toString();

        // 1) Exact mapping
        if (keyToPartition.containsKey(key)) {
            int p = keyToPartition.get(key);
            // safety: ensure p is a valid partition index
            if (p >= 0 && p < numPartitions) return p;
        }

        // 2) Prefix rule: keys starting with "vip-" go to partition 2 (if exists)
        if (key.startsWith("vip-")) {
            int p = 2 % numPartitions; // safe if fewer partitions
            return p;
        }

        // 3) Default: hash the key (same as default Kafka partitioner behaviour)
        if (keyBytes != null) {
            return Utils.toPositive(Utils.murmur2(keyBytes)) % numPartitions;
        } else {
            return Utils.toPositive(key.hashCode()) % numPartitions;
        }
    }

    @Override
    public void close() {
        
    }
}