package com.pack.kafkaApp;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.utils.Utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PaymentParti implements Partitioner{

	private Map<String, Integer> routing;
	@Override
	public void configure(Map<String, ?> configs) {
		try {
			InputStream is= getClass().getResourceAsStream("/routing.json");
			routing= new ObjectMapper().readValue(is,new TypeReference<Map<String, Integer>>() {});
		
			}catch (Exception e) {
		  routing=Map.of();
	}}

	@Override
	public int partition(String topic, Object keyobj, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		 int count= cluster.partitionCountForTopic(topic);
		 if(keyobj == null) {
			 return 0;
		 }
		String key= keyobj.toString().toLowerCase();
		if(routing.containsKey(key)) {
			return routing.get(key) % count;
		}
		return Utils.toPositive(key.hashCode()) % count;
	}

	@Override
	public void close() {
		
		
	}

}
