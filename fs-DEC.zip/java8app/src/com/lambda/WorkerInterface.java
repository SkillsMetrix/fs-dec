package com.lambda;


// SAM
public interface WorkerInterface {
	
	public void doSomeWork();

}
