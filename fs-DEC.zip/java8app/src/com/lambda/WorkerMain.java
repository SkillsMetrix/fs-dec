package com.lambda;

public class WorkerMain {
	
	public static void execute(WorkerInterface worker) {
		worker.doSomeWork();
	}
	
	public static void main(String[] args) {
		execute(new WorkerInterface() {
			
			@Override
			public void doSomeWork() {
				 System.out.println("Called using regular way");
				
			}
		});
	}
	 

}
