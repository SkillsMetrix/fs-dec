package banking;

public class BankingMain {
	
	public static void main(String[] args) {
		ICICI bank= new ICICI();
		
		System.out.println("Printing initial Balance: "+bank.getBalance());
		System.out.println("withdraw method called ....!");
		bank.withdrawAmount(100);
		
		System.out.println("Printing final Balance: "+bank.getBalance());
		
		bank.purchaseMF();
		bank.sellMF();
		bank.purchaseInsurance();
		bank.claimInsurance();
	}

}
