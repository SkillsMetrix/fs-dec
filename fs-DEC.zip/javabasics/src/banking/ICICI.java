package banking;

public class ICICI implements RBI, SEBI, IRDA{
	
	public int initialBalance=5000;

	@Override
	public void addDeposits(int amount) {
		 initialBalance =initialBalance+amount;
		
	}

	@Override
	public int getBalance() {
		// TODO Auto-generated method stub
		return initialBalance;
	}

	@Override
	public int withdrawAmount(int amount) {
		 initialBalance= initialBalance-amount;
		return initialBalance;
	}

	@Override
	public void purchaseMF() {
		System.out.println("ICICI MF Purchased");
		
	}

	@Override
	public void sellMF() {
		System.out.println("ICICI MF sold");
		
	}

	@Override
	public void purchaseInsurance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void claimInsurance() {
		// TODO Auto-generated method stub
		
	}

}
