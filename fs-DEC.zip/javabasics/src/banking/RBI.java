package banking;

public interface RBI {
	
	public void addDeposits(int amount);
	
	public int getBalance();
	
	public int withdrawAmount(int amount);

}
