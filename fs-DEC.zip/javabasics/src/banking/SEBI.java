package banking;

public interface SEBI {
	
	public void purchaseMF();
	public void sellMF();

}
