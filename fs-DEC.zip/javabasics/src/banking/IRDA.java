package banking;

public interface IRDA {
	
	public void purchaseInsurance();
	public void claimInsurance();
}
