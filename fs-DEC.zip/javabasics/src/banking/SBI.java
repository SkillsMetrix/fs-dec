package banking;

public class SBI implements RBI{
	
	public int initialBalance=1000;

	@Override
	public void addDeposits(int amount) {
		 initialBalance =initialBalance+amount;
		
	}

	@Override
	public int getBalance() {
		// TODO Auto-generated method stub
		return initialBalance;
	}

	@Override
	public int withdrawAmount(int amount) {
		 initialBalance= initialBalance-amount;
		return initialBalance;
	}

}
