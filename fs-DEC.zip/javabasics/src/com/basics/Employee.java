package com.basics;

public class Employee {
	
	// define class properties
	
	private int empId;
	private String empName;
	private String empCity;

	// getters and setters methods
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
	// default cons
	public Employee() {
		System.out.println("Inside Default Cons");
	}
	public Employee(int empId, String empName, String empCity) {
		 
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empCity=" + empCity + "]";
	}
	
	
	
	
	

}
