package com.basics;

public class EmployeeMain {
	
	public static void main(String[] args) {
		// creating emp obj
		Employee emp1 = new Employee();
		Employee emp2 = new Employee();
		
		emp1.setEmpId(101);
		emp1.setEmpName("Rajesh");
		emp1.setEmpCity("chennai");
		
		System.out.println(emp1.getEmpId() + " "+emp1.getEmpName() + " " + emp1.getEmpCity());
		
		
		emp2.setEmpId(102);
		emp2.setEmpName("Manish");
		emp2.setEmpCity("Hyderabad");
		
		System.out.println(emp2.getEmpId() + " "+emp2.getEmpName() + " " + emp2.getEmpCity());
		
		
		Employee emp3= new Employee(103, "SAM", "NY");
		System.out.println(emp3);
		
		//System.out.println(emp1.hashCode());
		//System.out.println(emp2.hashCode());
	}

}
