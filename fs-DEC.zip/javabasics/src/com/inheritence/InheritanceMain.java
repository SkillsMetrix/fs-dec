package com.inheritence;

public class InheritanceMain {
	
	public static void main(String[] args) {
		
		Employee emp1= new Manager();
		
		Employee emp2= new QA();
		
		
		System.out.println(emp1.showDetails());
		System.out.println(emp2.showDetails());
	}

}
