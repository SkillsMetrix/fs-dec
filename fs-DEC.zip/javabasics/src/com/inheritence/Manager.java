package com.inheritence;

public class Manager extends Employee{

	@Override
	public void addDetails() {
		System.out.println("Add Manager Details");
		
	}

	@Override
	public String showDetails() {
		// TODO Auto-generated method stub
		return "Manager";
	}
	
	public void showUsers() {
		System.out.println("Manager Details...!");
	}

}
