package com.inheritence;

public abstract class Employee {
	
	public abstract void addDetails();
	public abstract String showDetails();
	
	public void showUsers() {
		System.out.println("User Details...!");
	}

}
