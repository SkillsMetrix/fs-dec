package com.inheritence;

public class QA extends Employee{

	@Override
	public void addDetails() {
		System.out.println("Add QA Details");
		
	}

	@Override
	public String showDetails() {
		// TODO Auto-generated method stub
		return "QA";
	}

}
