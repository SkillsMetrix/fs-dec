package collectionsdemo;

import java.util.ArrayList;
import java.util.List;

public class LIstDemo {
	public static void main(String[] args) {
		
		List<Employee> al= new ArrayList<Employee>();
		
		al.add(new Employee(101, "Mukesh", "Delhi"));
		al.add(new Employee(102, "Dipti", "Mumbai"));
		al.add(new Employee(103, "shakti", "Indore"));
		
		for (Employee emp: al) {
			System.out.println(emp);
		}
	}

}
