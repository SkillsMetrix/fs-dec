package com.model;

public record User(Long id,String username,String email) {

}
