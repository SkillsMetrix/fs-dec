package com.model;

public record Payment(
		String paymentId,
		String userId,
		String type, // UPI.CARD,CASH
		double amount
		
		
		) {

}
