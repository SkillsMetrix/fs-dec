package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Payment;
import com.model.User;
import com.producers.PaymentProducer;
import com.producers.UserProducer;

@RestController
@RequestMapping("/payments")
@CrossOrigin
public class AppController {
	
	@Autowired
	private UserProducer userProducer;
	@Autowired
	private PaymentProducer producer;
	

	@PostMapping("/register")
	public String registerUser(@RequestBody User user) {
		
		userProducer.send(user);
		 
		return "User Added Successfully";
	}
	@PostMapping("/pay")
	public String payment(@RequestBody Payment payment) {
		producer.send(payment);
		
		return "Payment Added";
	}
	
	
}
