package com.consumers;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.model.Payment;

@Service
public class PaymentConsumer {
	
	@KafkaListener(topics = "payment-topic",groupId = "payment-group")
	public void consume(Payment payment) {
		System.out.println("✅ Processing Payment...!");
		System.out.println("Type "+ payment.type());
		System.out.println("Amount "+ payment.amount());
	}

}
