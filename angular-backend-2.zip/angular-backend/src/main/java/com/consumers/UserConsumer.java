package com.consumers;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.model.User;
@Service
public class UserConsumer {
	@KafkaListener(topics = "user-topic",groupId = "user-group")
	public void consume(User user) {
		System.out.println("✅ User Registered Saved...!");
		System.out.println("UserName "+ user.username());
		System.out.println("Email "+ user.email());
	}
}
