package com.producers;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.model.Payment;

@Service
public class PaymentProducer {
	
	private final KafkaTemplate<String, Payment> kafkaTemplate;
	
	public PaymentProducer(KafkaTemplate<String, Payment> kafkaTemplate) {
		this.kafkaTemplate=kafkaTemplate;
	}
	
	public void send(Payment payment) {
		kafkaTemplate.send("payment-topic",payment.paymentId(),payment);
	}
	

}
