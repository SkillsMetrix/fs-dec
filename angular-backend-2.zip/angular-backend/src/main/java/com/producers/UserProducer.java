package com.producers;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.model.User;
@Service
public class UserProducer {

	
private final KafkaTemplate<String, User> kafkaTemplate;
	
	public UserProducer(KafkaTemplate<String, User> kafkaTemplate) {
		this.kafkaTemplate=kafkaTemplate;
	}
	
	public void send(User user) {
		kafkaTemplate.send("user-topic",user);
	}
}
