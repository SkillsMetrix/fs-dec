import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MyappComponent } from './components/myapp/myapp.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,MyappComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'standalone-app';
}
