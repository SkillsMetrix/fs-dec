import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Summary } from '../../shared/summary.pipe';
import { Reverse } from '../../shared/Reverse.pipe';
import { ColorChanger } from '../../shared/colorchanger.directive';

@Component({
  selector: 'app-myapp',
  standalone: true,
  imports: [ CommonModule,Summary,Reverse,ColorChanger],
  templateUrl: './myapp.component.html',
  styleUrl: './myapp.component.css'
})
export class MyappComponent {

  usersData=['admin','manager','tester']

  users={
    name:'suneth',
    income:789876,
    rating:4.7786,
    DOJ:new Date('11/11/2011'),
    description:'this is all about user app',
    city:'mumbai'
  }

}
