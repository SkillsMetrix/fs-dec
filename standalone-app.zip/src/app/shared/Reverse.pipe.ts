
import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'reverse',
    standalone:true
})
export class Reverse implements PipeTransform{
    transform(value: string) {
           return value.split('').reverse().join('')
    }
}