import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appFontface]',
  standalone: true
})
export class FontfaceDirective {

 fontWeight = '';
 
   @HostListener('mouseenter')
   addFF() {
     this.fontWeight = 'bold';
   }
   
   @HostListener('mouseleave')
   removeColor() {
     this.fontWeight='normal';
   }
   @HostBinding('style.fontWeight')
   get applyStyle() {
     return this.fontWeight;
   }

}
