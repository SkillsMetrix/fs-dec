import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { RegisterComponent } from './components/register/register.component';
import { FormService } from './shared/form.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RegisterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'kafka-client';
  constructor(private fs: FormService) {}
  payToConsumer(type: string) {
    this.fs
      .pay({
        paymentId: '101',
        userId: '201',
        type,
        amount: 400,
      })
      .subscribe();
  }
}
