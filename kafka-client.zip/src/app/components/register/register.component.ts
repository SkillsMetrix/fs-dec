import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { MaterialModule } from '../../material.module';
import { CommonModule } from '@angular/common';
import { FormService } from '../../shared/form.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule,MaterialModule,CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  addUser(nf:NgForm){
     this.fs.register(nf.value);
      
  }
  constructor(private fs:FormService){}
}
