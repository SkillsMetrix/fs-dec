import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',

})

export class FormService {

  constructor(private http:HttpClient) { }

  register(data:any){
    this.http.post('http://localhost:8080/payments/register',data)
    .subscribe(data => console.log(data)
    )
  }
  pay(payment:any){
    return this.http.post('http://localhost:8080/payments/pay',payment)
  }
}
