import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormService {
  constructor(private http:HttpClient){}
  addUser(user:any){
     this.http.post('http://localhost:3000/users',user)
     .subscribe(data=> console.log('user is added ',data)
     )
    
  }
  login(user:any){
   console.log(user);
   
  }

  
}
