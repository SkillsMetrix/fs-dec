import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../../shared/form.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  loginForm!: FormGroup;
  uname!: FormControl;
  password!: FormControl;

  createFormControl(){
    this.uname= new FormControl('',Validators.required)
     this.password= new FormControl('',[Validators.required,Validators.minLength(6)])
  }
  createForm(){
    this.loginForm= new FormGroup({
      uname:this.uname,
      password:this.password
    })
  }
  constructor(private fs:FormService){
    this.createFormControl()
    this.createForm()
  }
  login(){
   this.fs.login(this.loginForm.value)
    
  }
}
