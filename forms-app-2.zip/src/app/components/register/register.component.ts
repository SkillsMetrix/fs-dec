import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormService } from '../../shared/form.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  constructor(private fs:FormService){}
  addUser(ab:NgForm){
   this.fs.addUser(ab.value)
    
  }

}
