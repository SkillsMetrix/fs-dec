package com.project;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class BookingService {
	private List<Flight> flights;
	
	private DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");
	
	public BookingService() {
		flights= new ArrayList<Flight>(Arrays.asList(
				new Flight("AI101", "Delhi","Mumbai", LocalDateTime.now().plusHours(5), BigDecimal.valueOf(5500)),
				new Flight("AI102", "Delhi","Bangalore", LocalDateTime.now().plusHours(3), BigDecimal.valueOf(6500)),
				new Flight("AI103", "Mumbai","Chennai", LocalDateTime.now().plusHours(6), BigDecimal.valueOf(4800)),
				new Flight("AI104", "Delhi","Mumbai", LocalDateTime.now().plusHours(2), BigDecimal.valueOf(6000))
				));
	}
	public List<Flight> searchFlight(String origin,String destination){
		return flights.stream()
				.filter(f -> f.getOrigin().equalsIgnoreCase(origin))
				.filter(f ->f.getDestination().equalsIgnoreCase(destination))
				.sorted(Comparator.comparing(Flight :: getDepartureTime))
				.collect(Collectors.toList());
	}
		
	
	public List<Flight> searchFlightByTimeRange(LocalDateTime start,LocalDateTime end){
		return flights.stream()
				 .filter(f -> !f.getDepartureTime().isBefore(start) && !f.getDepartureTime().isAfter(end))
				 .collect(Collectors.toList());
				 
	}
	// search flight by Flightno
	public Optional<Flight> getFlight(String fno){
		return flights.stream()
				.filter(f -> f.getFlightNumber().equalsIgnoreCase(fno))
				.findFirst();
	}
	
	// booking the passenger
	
	public void bookPassenger(String fno,Passengers passenger) throws BookingException{
		Flight flight= getFlight(fno)
				.orElseThrow(() -> new BookingException("Flight " + fno + " not found" ));
		if(flight.getPassengers().size() >=2) {
			throw new BookingException("Flight " + fno + " is Fully Booked");
		}
		flight.addPassenger(passenger);
		System.out.println("✅💫 Booking COnfirmed for " + passenger.getName() + " on flight " + fno);
	}
		
	public void calculateRevenue() {
		BigDecimal total= flights.stream()
				.map(f -> f.getPrice().multiply(BigDecimal.valueOf(f.getPassengers().size())))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		System.out.println("💰 Total revenue "+ total);
	}
	
	public void showBookings() {
		flights.forEach(flight -> {
			System.out.println("\n ✈️ Flight: "+ flight.getFlightNumber() + " (" + flight.getOrigin() + " -> " + flight.getDestination() +
					") "+ flight.getDepartureTime().format(formatter) + " Price 💰 " +flight.getPrice());
			if (flight.getPassengers().isEmpty()) {
				System.out.println("No Passengers booked yet");
			}else {
				flight.getPassengers().forEach(p -> System.out.println(" - "+p));
			}
		});
	}
	

}
