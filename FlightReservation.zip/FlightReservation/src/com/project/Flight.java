package com.project;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Flight {
    private String flightNumber;
    private String origin;
    private String destination;
    private LocalDateTime departureTime;
    private BigDecimal price;
    private List<Passengers> passengers;

     
    public Flight(String flightNumber, String origin, String destination,
                  LocalDateTime departureTime, BigDecimal price, List<Passengers> passengers) {
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.departureTime = departureTime;
        this.price = price;
         
        this.passengers = new ArrayList<>(passengers);
    }

    
    public Flight(String flightNumber, String origin, String destination,
                  LocalDateTime departureTime, BigDecimal price) {
        this(flightNumber, origin, destination, departureTime, price, new ArrayList<>());
    }

    public String getFlightNumber() { return flightNumber; }
    public String getOrigin() { return origin; }
    public String getDestination() { return destination; }
    public LocalDateTime getDepartureTime() { return departureTime; }
    public BigDecimal getPrice() { return price; }
    public List<Passengers> getPassengers() { return passengers; }

    public void addPassenger(Passengers passenger) {
        passengers.add(passenger);
    }

    public void removePassenger(String email) {
        passengers.removeIf(p -> p.getEmail().equalsIgnoreCase(email));
    }

    @Override
    public String toString() {
        return String.format("%s (%s -> %s) %s Price: ₹%s",
                flightNumber, origin, destination, departureTime, price);
    }
}